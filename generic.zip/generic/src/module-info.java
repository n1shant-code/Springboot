
module generic {
}